Nome = input('Digite seu nome:')
Idade = int(input('Digite sua idade'))
dias = Idade*365
print(f'{Nome}, você já viveu {dias} dias.')