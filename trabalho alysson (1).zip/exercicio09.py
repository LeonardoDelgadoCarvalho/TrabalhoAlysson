Preço = float(input('informe o preço do litro da gasolina:'))
Valor = float(input('Informe o valor em reais que será abastecido:'))
Listros = Valor/Preço
print(f'Será abastecido {Listros:.2f} de gasolina')