Nome = input(('informe seu nome:'))
N1 = float(input('Informe sua nota de Laboratório de Programação:'))
N2 = float(input('Informe sua nota de Tgs:'))
N3 = float(input('Informe sua nota de web development:'))
Média = (N1+N2+N3)/3
print(f'Sua média foi:{Média:.2f}')
