A = int(input('Informe um valor para A:'))
B = int(input('Informe um valor para B:'))
C = B
D = A
print(f'A:{C}\nB:{D}')
