Prato = float(input('Peso do prato:'))
Valor = 19*Prato
print(f'Valor a ser pago é de:{Valor:.2f}')