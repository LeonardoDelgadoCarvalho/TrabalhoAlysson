P = int(input('Quantidades de camisetas P:'))
M = int(input('Quantidades de camisetas M:'))
G = int(input('Quantidades de camisetas G:'))
V_P = P*10
V_M = M*12
V_G = G*15
V_total = V_P+V_M+V_G
print(f'Valor total das camisetas é de:{V_total}')