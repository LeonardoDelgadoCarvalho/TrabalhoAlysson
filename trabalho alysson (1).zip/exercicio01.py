Distancia = float(input('digite a distância percorrida:'))
tempo = float(input('digite o tempo gasto:'))
Vm = Distancia/tempo
print(f'A sua velocidade média foi de:{Vm} k/h')