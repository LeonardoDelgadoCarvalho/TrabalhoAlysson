Valor = float(input('Valor da roupa:'))
Desconto = Valor*(30/100)
Valor_f = Valor-Desconto
print(f'O valor com o desconto de 30% será de:{Valor_f} Reais')