Cavalos = int(input('digite a quantidade de cavalos:'))
Ferraduras = Cavalos*4
print(f'serão necessárias {Ferraduras} Ferraduras')