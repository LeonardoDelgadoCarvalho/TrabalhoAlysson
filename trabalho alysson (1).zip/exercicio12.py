Valor = float(input('informe o valor do produto:'))
Prestação = Valor/5
print(f'O valor da pretação será de:{Prestação:.2f}')