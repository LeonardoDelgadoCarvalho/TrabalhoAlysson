depósito = float(input('Valor depositado:'))
rendimento = (0.7/100)*depósito
V_final = depósito+rendimento
print(f'com o rendimento mensal de 0,70% a.m, sua poupança agora é de {V_final:.2f} reais')